<script lang="ts">
	import Calendar from "$lib/Calendar.svelte"
</script>

<div class="w-screen h-screen bg-slate-500 p-10 flex items-center justify-center">
  <Calendar />
</div>